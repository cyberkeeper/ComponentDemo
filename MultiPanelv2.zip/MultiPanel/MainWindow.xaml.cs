﻿using Microsoft.Win32;
using People;
using System.Windows;
using System.Windows.Controls;

namespace MultiPanel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// List of Person instances used in this example
        /// </summary>
        public List<Person> personSource;

        private string _fruit;

        /// <summary>
        /// Get the selected favourite fruit
        /// </summary>
        public string Fruit { get => _fruit; }

        /// <summary>
        /// Main entry point
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            //center the window
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            //initialise the demo data
            InitDataValues();
            InitComponents();
            //set the navigation buttons
            SortNavigation();
        }

        /// <summary>
        /// Load in the initial data to be used
        /// </summary>
        private void InitDataValues()
        {
            //create new instance of List and populate with objects of type person
            personSource =
            [
                new Person("Ado", "Main St", "Anywhere", "PA121RF", 23),
                new Person("Bob", 32),
                new Person("Carol", 29),
                new Person("Diane", "High St", "Overton", "G452ED", 21),
                new Person("Edgar", 34),
                new Person("Fiona", 19),
            ];
        }

        /// <summary>
        /// Populate the Listbox and the combobox with the data setup in the InitDataValues method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Reload_Click(object sender, RoutedEventArgs e)
        {
            CbThings.Items.Clear();
            LbThings.Items.Clear ();
            InitComponents();
        }

        /// <summary>
        /// populate the list and comboboc
        /// </summary>
        private void InitComponents()
        {
            //load the data in the combobox and the listbox
            foreach (Person person in personSource)
            {
                CbThings.Items.Add(person);
                LbThings.Items.Add(person);
            }

            //check that the both components contains something and then set first index to be selected
            if ((!CbThings.Items.IsEmpty) && (!LbThings.Items.IsEmpty))
            {
                //set the first index as selected
                CbThings.SelectedIndex = 0;
                LbThings.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// Get what item was selected in the comboBox and the listBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GetSelectedData(object sender, RoutedEventArgs e)
        {
            int personIndex = CbThings.SelectedIndex;
            Person personObj = CbThings.SelectedItem as Person;

            TxtComboBoxIndex.Text = personIndex.ToString();
            TxtComboBoxObject.Text = personObj.Print();

            int personIndex2 = LbThings.SelectedIndex;
            Person personObj2 = LbThings.SelectedItem as Person;

            TxtListBoxIndex.Text = personIndex2.ToString();
            TxtListBoxObject.Text = personObj2.Print();
        }

        /// <summary>
        /// Called when the favourite fruit radio button is changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnFruitChecked(object sender, RoutedEventArgs e)
        {
            //cast the sender object to what we expect
            RadioButton rbFruit = (RadioButton)sender;
            txtFavouriteFruit.Text = $"Currently selected fruit: {rbFruit.Tag}";

            _fruit = rbFruit.Content as string;

        }

        /// <summary>
        /// set the content as the selected fruit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GetSelectedFruit(object sender, RoutedEventArgs e)
        {
            txtSelectedFruit.Text = _fruit;
        }

        /// <summary>
        /// Move to the next tab
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NextTab(object sender, RoutedEventArgs e)
        {
            // Check if there are more tabs
            if (Viewer.SelectedIndex < Viewer.Items.Count - 1)
            {
                // Select the next tab
                Viewer.SelectedIndex++;


            }
            //sort buttons
            SortNavigation();
        }

        /// <summary>
        /// Move to previous tab
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackTab(object sender, RoutedEventArgs e)
        {
            // Check if there are more tabs
            if (Viewer.SelectedIndex > 0)
            {
                // Select the next tab
                Viewer.SelectedIndex--;
            }
            //sort buttons
            SortNavigation();
        }

        /// <summary>
        /// Enable or disable next/back navigation buttons as required.
        /// </summary>
        private void SortNavigation()
        {
            //if at end disable button
            btnNext.IsEnabled = (Viewer.SelectedIndex >= Viewer.Items.Count - 1) ? false : true;
            //the following does the exact same as the above line
            /*if (Viewer.SelectedIndex >= Viewer.Items.Count - 1)
            {
                btnNext.IsEnabled = false;
            }
            else
            {
                btnNext.IsEnabled = true;
            }*/

            //Same as above but with the back button
            btnBack.IsEnabled = (Viewer.SelectedIndex == 0) ? false : true;
        }

        /// <summary>
        /// Show the selected data in a new window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShare_Click(object sender, RoutedEventArgs e)
        {
            //get selected fruit
            String fruit = _fruit;

            //get selected person
            Person p = CbThings.SelectedItem as Person;

            Second anWindow = new Second();

            anWindow.SetData(fruit, p);
            anWindow.Owner = this;
            this.Hide();
            anWindow.Show();

            //registers an event handler for the Closed event of the anWindow 
            anWindow.Closed += anWindow_Closed;

        }

        /// <summary>
        /// Event handler for the Second window closed event. Retrieves the data which is stored in 
        /// the ReturnedData
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void anWindow_Closed(object sender, EventArgs e)
        {
            string receivedData = ((Second)sender).ToBeReturnedData;
            txtRetrieved.Text = receivedData;
        }

        /// <summary>
        /// When the selected tab is changed, ensure that the back and next buttons are enabled/disabled appropriately
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Viewer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortNavigation();
        }

        /// <summary>
        /// A single method that is used for both check boxes. Uses the component name.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cb_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            string compName = cb.Name;

            txtCBNum.Text = compName + " is checked";
        }

        /// <summary>
        /// A single method that is used for both check boxes. Uses the component tag.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cb_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;

            string compTag = cb.Tag as string;

            txtCBNum.Text = compTag + " is unchecked";
        }

        /// <summary>
        /// check that the user really want to exit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AppWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("Are you sure?", "MultiPanel", MessageBoxButton.OKCancel, MessageBoxImage.Hand) == MessageBoxResult.Cancel)
            {
                //cancel the close event
                e.Cancel = true;
            }

        }
    }
}